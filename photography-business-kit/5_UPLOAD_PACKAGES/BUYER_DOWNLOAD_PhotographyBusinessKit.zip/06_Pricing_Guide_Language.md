# Pricing Guide Language for Photographers
## How to Present Your Investment, Handle Objections, and Raise Your Rates

---

### THE MINDSET SHIFT

You are not a commodity. You are not competing on price. You are offering something specific, irreplaceable, and deeply personal.

The language you use when presenting your pricing either reinforces that — or undermines it. This guide gives you the exact words.

---

## SECTION 1: HOW TO WRITE YOUR INVESTMENT GUIDE

---

### WHAT TO CALL YOUR PRICES

❌ "Prices" — sounds transactional  
❌ "Rates" — sounds like a contractor  
❌ "Fees" — sounds bureaucratic  
✅ "Investment" — reflects the lasting value  
✅ "Packages" — groups services intuitively  
✅ "Collections" — used in luxury photography; signals premium positioning  

---

### LANGUAGE TO USE (AND AVOID)

**Use:**
- "Your investment includes..."
- "This collection gives you everything you need to..."
- "My clients find that the [middle/top tier] covers most families/couples comfortably"
- "The images from your session are yours for life"
- "This is a once-in-a-lifetime moment — the investment reflects that"

**Avoid:**
- "I know it's expensive, but..."
- "I'm cheaper than most photographers because..."
- "Sorry, I can't go lower than..."
- "It only costs..."
- Apologizing for your price in any form

---

### THE INVESTMENT PAGE — OPENING PARAGRAPH

Write one of these as your intro before listing packages:

**Version A (Direct):**
"Thank you for inquiring! My investment guide is below. I believe in being transparent with pricing so you can make the decision that's right for you. Every package includes [list key inclusions]. If you have questions, I'm always happy to chat."

**Version B (Value-First):**
"I believe your photos should outlast the moment they captured. Every session I book is treated as the only session I'm shooting that day — full preparation, full presence, full commitment to delivering images you'll treasure for decades. Here's what that looks like:"

**Version C (Emotional):**
"These are the photos your kids will show their kids. They're the images that end up on walls, in frames, in the slideshow at the party everyone cries at. Here's my investment guide — because something that lasts forever is worth investing in:"

---

## SECTION 2: PACKAGE PRESENTATION TEMPLATES

---

### PACKAGE TEMPLATE A — 3-Tier Structure (Portrait / Family)

---

**[PACKAGE NAME — e.g., Essential / Classic / Signature]**

**Essential Session — $[Price]**
- [X]-hour session
- [X] fully edited digital images
- Online gallery access for [X] days
- Personal printing rights

Best for: quick updates, headshots, couples without children

---

**Classic Session — $[Price]**  ← *Most Popular*
- [X]-hour session
- [X] fully edited digital images
- Online gallery access for [X] days
- Personal printing rights
- [One additional value — e.g., location scouting, outfit consultation, rush delivery option]

Best for: families, extended sessions, clients who want flexibility and variety

---

**Signature Session — $[Price]**
- [X]-hour session
- [X] fully edited digital images
- Online gallery access for [X] days
- Personal printing rights
- [Additional values — engagement session + wedding combo, multiple locations, video clips, etc.]
- Priority scheduling and dedicated pre-session planning call

Best for: clients who want the full experience and maximum image variety

---

### PACKAGE TEMPLATE B — Wedding Photography

---

**[Collection A Name] — $[Price]**
- [X] hours of coverage
- One photographer
- [X] fully edited images
- Online gallery ([X]-month access)
- Personal printing rights

---

**[Collection B Name] — $[Price]** ← *Most Popular*
- [X] hours of coverage
- Lead photographer + second shooter
- [X] fully edited images
- Online gallery ([X]-month access + download)
- Engagement session included
- Personal printing rights

---

**[Collection C Name] — $[Price]**
- [X] hours of coverage
- Lead photographer + second shooter
- [X]+ fully edited images
- Engagement session + rehearsal dinner coverage
- Fine-art wedding album ([X] pages)
- Online gallery (lifetime access)
- Personal printing rights + commercial use license

---

### PACKAGE TEMPLATE C — Brand / Headshots

---

**Brand Starter — $[Price]**
- [X]-hour session
- [X] edited images across [X] looks/outfits
- Commercial use license
- Online gallery download

---

**Brand Builder — $[Price]**
- [X]-hour session
- [X] edited images across [X]+ looks
- [X] short video clips (15–30 seconds, unedited)
- Commercial use license
- Priority 5-day turnaround

---

## SECTION 3: ADD-ON MENU LANGUAGE

---

**How to introduce add-ons:**
"To customize your package, the following additions are available:"

| Add-On | Investment |
|--------|-----------|
| Rush delivery ([X]-day turnaround) | $[X] |
| Additional edited images (per 10) | $[X] |
| Additional session hour | $[X] |
| Video highlight reel ([X] minutes) | $[X] |
| Fine-art album ([X] pages) | $[X] |
| Canvas or print credit | $[X] |
| Second location | $[X] |
| Travel beyond [X] miles | $[X]/mile |
| Holiday card design (set of [X]) | $[X] |

---

## SECTION 4: PAYMENT PLAN LANGUAGE

---

**How to offer payment plans without it feeling desperate:**

"To make your investment more manageable, I offer a simple payment plan:

**Booking deposit:** $[X] (secures your date — non-refundable)  
**Second payment:** $[X] due [X weeks/days before session]  
**Final payment:** Balance due [X days before session / at session]

Payment plans are available on all packages. Your session date is not confirmed until the deposit is received."

---

**For wedding packages:**

"A [X]% retainer secures your wedding date. The remaining balance can be divided into [2–3] payments, with the final balance due [30] days before your wedding. Dates are not held without a signed contract and retainer."

---

## SECTION 5: THE PRICING CONVERSATION — SCRIPTS

---

### SCRIPT PC-01 — Sharing Pricing for the First Time

**In an email:**

"Thank you for reaching out — I'd love to work with you!

I want to make sure we're a good fit before going into all the details, so I'd love to ask a couple of quick questions: [2-3 discovery questions about their session, date, and what they're looking for].

Once I have a sense of what you need, I can share the investment guide that makes the most sense for your situation. Or if you'd prefer to see everything upfront, I'm happy to send my full investment guide now — just let me know."

**Why this works:** It pre-qualifies the lead before sharing pricing, which frames the price conversation in context of their needs rather than a standalone number.

---

### SCRIPT PC-02 — When They Ask "How Much Do You Charge?"

"My packages start at $[X] and go up to $[X] depending on coverage and inclusions. Most clients find the [middle tier / most popular package] covers everything they need. Would it help to jump on a quick call so I can point you toward exactly the right fit for what you're looking for?"

---

### SCRIPT PC-03 — Presenting Price With Confidence

"Your investment for [what they want] would be $[X]. That includes [list the top 3–4 inclusions]. I've set aside [their date] on my calendar and can send over the contract today if you'd like to move forward."

[Then stop talking. Don't fill the silence with justifications.]

---

## SECTION 6: HANDLING OBJECTIONS

---

### OBJECTION 01 — "Can You Do It for Less?"

**Response A (Firm No — for clients clearly below budget):**
"I appreciate you asking directly! I'm not able to adjust my pricing — my packages are set based on the time, skill, and experience that goes into every session. That said, I do have a [mini session / shorter session / off-peak option] at $[X] that might work for what you need. Would that be helpful?"

**Response B (Partial Flexibility — off-peak or payment plan):**
"My package pricing stays consistent, but I do offer payment plans that might make the investment more manageable. I also occasionally have off-season availability with slightly adjusted pricing — if [month/season] works for you, I can check availability."

**Response C (Polite Exit for Persistent Price Shoppers):**
"I understand — budget is real and I want you to find the right photographer for yours. I'm probably not the right fit at your price point, but I'd encourage you to look for photographers who are building their portfolio or offering mini sessions — you'll find great quality at lower price points through those channels. Best of luck with your session!"

---

### OBJECTION 02 — "I Found Someone Cheaper"

"That makes sense — photography pricing varies a lot, and cheaper isn't always the wrong choice. It really depends on what matters most to you in the final product and the experience.

What I'd encourage you to do is look through both of our galleries and notice how you feel about the images — not just whether they look 'good,' but whether they feel like something you'd want on your wall in 10 years.

If my work resonates more, I'd love to work with you. If theirs does, they're probably a better fit — and that's okay too."

---

### OBJECTION 03 — "I Wasn't Expecting It to Be That Much"

"I completely understand — professional photography can be a bigger investment than people realize before they start looking. Can I ask what you were expecting? That helps me understand whether there's a package that might work better, or whether this just isn't the right fit right now.

I never want anyone to feel pressured into booking something that doesn't feel right financially."

---

## SECTION 7: WHEN AND HOW TO RAISE YOUR RATES

---

### 7 SIGNALS IT'S TIME TO RAISE YOUR RATES

1. Your inquiry volume has increased (demand is outpacing supply)
2. You're booking more than [X] months in advance consistently
3. No one is pushing back on your pricing
4. Your work has measurably improved since you last adjusted
5. Your cost of doing business has increased (equipment, software, insurance, education)
6. You've built a significant portfolio and testimonial base
7. You've been at the same price for more than a year

---

### HOW MUCH TO RAISE

**Conservative:** 10–15% (minimal friction, barely noticed by most)  
**Standard:** 15–25% (feels more significant but still reasonable)  
**Bold move:** 25–40% (use when significantly repositioning your brand)

---

### RATE INCREASE EMAIL TO EXISTING CLIENTS

**Subject:** Booking for [Year] — a note on pricing

---

Hi [First Name],

I wanted to reach out personally before I share my new pricing publicly.

As of [Date / January 1 / new booking cycle], my [session type] investment is adjusting to $[New Price] (currently $[Old Price]).

If you'd like to rebook at my current rates, I'm holding [a few spots / specific dates] for returning clients through [Date]. After that, new bookings will be at the updated investment.

It's always a joy working with you, and I hope we get to do it again soon.

[Your Name]

---

*© For personal and professional business use by the purchaser. Not for resale or redistribution.*
